import argparse
import json
import logging
import os
import shlex
from datetime import datetime
from pathlib import Path
from subprocess import Popen, PIPE
from time import sleep

import cv2
import requests
from gpiozero import LED  # type: ignore
from picamera2 import Picamera2, MappedArray  # type: ignore

from motor import MotorControl


'''
Image filename format
  individual images before stacking
    AAA-DDD_sentinelSSSS_stepperCCC_focusFFFF_posPPPP.png

  composite image after focus stacking
    DDD_sentinelSSSS_stepperCCC_focusFFFF_stack.png

    AAA  three-digit, zero-padded sequential identifier of image in a stack
    DDD  datetime stamp for image as YYYYMMDDTHHMMTZ
    SSSS four-digit, zero-padded Sentinel serial number
    CCC  three-digit zero-padded stepper position (1 step = 0.36°)
    FFFF four-digit, zero-padded value for focus metric
    PPPP four-digit, zero-padded value for the lens VCM position
'''

# settings
PATH_PI = Path('/home/sentinel/Pictures/')  # image path for Pi filesystem
PATH_USB = Path('/media/sentinel/SENTINEL/')  # image path for USB
URL_FS = ('https://spore-count.mib.manchester.ac.uk/'
          + 'fileserver/api/')  # fileserver URL
# credentials for uploading images
AUTH_FS = {'username': 'SentinelUpload',
           'password': 'Az%BiamZ7EZtEAz'}
CAM_LED = 21  # GPIO for camera light
SENTINEL_ID_FILE = '/home/sentinel/sentinelID.txt'  # to get ID
max_position = 1023  # for autofocus VCM
focus_stack_path = '/usr/local/bin/focus-stack'

# configure logger
logger = logging.getLogger(__name__)


def set_vcm_position(position):
    '''Sets position of voice coil motor on camera.

    Arguments:
    position -- 10-bit integer, 0=full in, 1023=full out

    Returns:
    new position (int)
    '''
    if position > max_position:
        position = max_position
    elif position < 0:
        position = 0
    else:
        transformed = (int(position) << 4) & 0x3ff0
    cmd = ('i2cset -y 10 0x0c '
           + '{:d} {:d}'.format((transformed >> 8) & 0x3f,
                                (transformed & 0xf0)))
    p = Popen(shlex.split(cmd))
    return position


def calc_focus(img, gauss=3, laplace=3):
    '''Calcuates the Laplacian of an image as a focus metric,
    that is, sharpness of edges.

    Arguments:
    img -- OpenCV image array

    Keyword arguments:
    gauss -- size of kernel for Gaussian blur (int, default = 3)
    laplace -- size of kernel for Laplacian (int, default = 3)
    '''
    return cv2.Laplacian(cv2.cvtColor(cv2.GaussianBlur(img,
                                                       (gauss, gauss),
                                                       0), cv2.COLOR_RGB2GRAY),
                         cv2.CV_16S, ksize=laplace).var()  # type: ignore


def take_image_stack(params):
    '''Acquires and saves images at equally spaced focus values,
    including nearest and furthest positions
    '''
    save_count = 0
    best_focus = 0
    slice_count = 0
    reference_focus = -1
    while slice_count < int(params['slices']):
        # set lens position
        new_position = max_position * slice_count // int(params['slices'] - 1)
        if params['arducam']:
            position = set_vcm_position(new_position)
            logger.debug('Focus set to {:d}'.format(position))
            sleep(0.2)

        request = params['picam2'].capture_request()  # type: ignore
        with MappedArray(request, 'main') as m:
            image = m.array[params['crop_y']:(params['crop_y']
                                              + params['crop_height']),
                            params['crop_x']:(params['crop_x']
                                              + params['crop_width']),
                            :].copy()
        request.release()
        logger.debug('Captured image')
        focus_metric = calc_focus(image)
        logger.info('Acquired image slice '
                    + '{:d} position {:d} '.format(slice_count, position)
                    + 'focus {:.1f}'.format(focus_metric))
        # save image if better than minimum focus metric
        if focus_metric >= params['minfocus']:
            file_name = ('{:03d}-'.format(save_count)
                         + params['image_ID']
                         + '_stepper{:03d}'.format(params['motor'].position)
                         + '_focus{:04.0f}'.format(focus_metric)
                         + '_pos{:04d}.png'.format(position))
            full_file = str(PATH_PI / params['image_dir'] / file_name)
            cv2.imwrite(full_file,
                        cv2.cvtColor(image, cv2.COLOR_BGR2RGB),
                        [cv2.IMWRITE_PNG_COMPRESSION, 5])
            logger.info('Image written to Pi')
            if params['USB']:
                cmd = ('cp ' + full_file + ' '
                       + str(PATH_USB / params['image_dir'] / file_name))
                p = Popen(shlex.split(cmd))
                logger.info('Image copied to USB memory stick')
            if focus_metric > best_focus:
                best_focus = focus_metric
                reference_focus = save_count
                logger.debug('reference image is '
                             + str(reference_focus))
            save_count += 1
        elif focus_metric < 0.01:
            logger.debug('Sensor not ready, retaking image')
            slice_count -= 1
            sleep(1)
        else:
            logger.debug('Image too blurry, discarding')

        slice_count += 1
    params['reference_focus'][params['motor'].position] = reference_focus
    logger.info('Image stack complete')
    return reference_focus


def focus_stack(params, angle, delete_images=False):
    '''Wavelet algorithm for focus stacking.
    https://github.com/PetteriAimonen/focus-stack
    Requires swap size of ~1MB on Pi Zero 2

    Keyword arguments:
    delete_images -- remove image files after stack generated (default False)
    '''
    if params['reference_focus'][angle] == -1:
        logger.warning('No images found for ' + str(angle / 25 * 9) + '°')
    else:
        cmd = (focus_stack_path
               + ' --output='
               + str(PATH_PI / params['image_dir']) + '/'
               + params['image_ID']
               + '_stepper{:03}'.format(angle)
               + '_stack.png'
               + ' --no-whitebalance'
               + ' --threads=3'
               + ' --batchsize=4'
               + ' --no-opencl'  # until it's built on RPi Zero 2
               + ' --reference='
               + str(params['reference_focus'][angle])
               + ' '
               + str(PATH_PI / params['image_dir']) + '/'
               + '*_stepper{:03}*.png'.format(angle))
        logger.debug('focus stack command: ' + cmd)
        p = Popen(cmd, shell=True, stdout=PIPE, stderr=PIPE)
        sout, serr = p.communicate()
        for line in sout.decode().rstrip().split('\r'):
            if len(line):
                logger.debug('focus-stack output ' + line)
        if len(serr):
            for line in serr.decode().rstrip().split('\r'):
                logger.debug('focus-stack errors ' + str(serr))
        logger.info('Stack written to Pi')
        if params['USB']:
            cmd = ('cp '
                   + str(PATH_PI / params['image_dir']) + '/'
                   + (params['image_ID'] +
                      '_stepper{:03}'.format(angle) + '_stack.png')
                   + ' '
                   + str(PATH_USB / params['image_dir']) + '/'
                   + params['image_ID'] + '_stepper{:03}'.format(angle) + '_stack.png')
            p = Popen(shlex.split(cmd))
            logger.debug('Stack copied to USB memory stick')
        if delete_images:
            os.remove(str(PATH_PI / params['image_dir']) + '/'
                      + '*_stepper{:03}*.png'.format(angle))


def ImageCapture(
        crop: tuple[float, float, float, float] = (0.0, 0.0, 1.0, 1.0),
        slices: int = 5,
        arducam: bool = True,
        tune: str = '',
        minfocus: float = 20.0,
        stack: bool = True,
        angles: int = -1,
        pansize: float = 9.0,
        uploadall: bool = False,
        delete_images: bool = False):

    # set up parameters dictionary to pass to functions
    params = {'slices': slices,
              'arducam': arducam,
              'tune': tune,
              'minfocus': minfocus,
              'stack': stack,
              'angles': angles,
              'pansize': pansize,
              'uploadall': uploadall,
              'reference_focus': {},
              'stepper_positions': []}

    # initialise hardware classes
    led = LED(CAM_LED)
    params['motor'] = MotorControl()
    # motor.on()
    params['picam2'] = Picamera2()
    # motor.off()

    # get Sentinel ID (data[7])
    with open(SENTINEL_ID_FILE, 'r') as f:
        sentinel_id = int(f.read().rstrip())
    logger.debug('Read Sentinel ID as {:d}'.format(sentinel_id))

    # check for whether USB is plugged in and accessible
    params['USB'] = True
    try:
        os.listdir(PATH_USB)
    except (PermissionError, FileNotFoundError) as err:
        logger.error('Unable to access USB memory stick: ', err)
        params['USB'] = False

    # set up directory and file names
    now = datetime.now()
    params['image_dir'] = Path('sentinel_{:04d}/'.format(sentinel_id)
                               + now.strftime('%Y-%m-%dT%H-%M%z'))
    params['image_ID'] = (now.strftime('%Y%m%dT%H%M%z')
                          + '_sentinel{:04d}'.format(sentinel_id))
    os.makedirs(str(PATH_PI / params['image_dir']), exist_ok=True)
    logger.debug('Created directory ' + str(PATH_PI / params['image_dir']))
    if params['USB']:
        try:
            os.makedirs(str(PATH_USB / params['image_dir']), exist_ok=True)
            logger.debug('Created directory ' +
                         str(PATH_USB / params['image_dir']))
        except (PermissionError, FileNotFoundError) as err:
            logger.error('Unable to access USB memory stick: ', err)
            USB = False

    # initialise camera
    capture_config = params['picam2'].create_still_configuration()
    # preview_config = picam2.create_preview_configuration()
    full_width, full_height = capture_config['main']['size']
    logger.debug('Sensor: {:d}x{:d}'.format(full_width, full_height))
    params['crop_x'] = int(full_width * crop[0])
    params['crop_y'] = int(full_height * crop[1])
    params['crop_width'] = int(full_width * crop[2])
    params['crop_height'] = int(full_height * crop[3])
    logger.debug('Crop: x = {:d}, y = {:d}'.format(
        params['crop_x'], params['crop_y']))
    logger.debug('Crop: w = {:d}, h = {:d}'.format(
        params['crop_width'], params['crop_height']))
    if params['arducam']:
        params['tune'] = '/home/sentinel/imx477_af.json'
    if tune != '':
        tuning = Picamera2.load_tuning_file(params['tune'])
        logger.info('Loaded tuning file ' + params['tune'])

    # turn on LED
    led.on()
    logger.debug('Camera LED on')

    # start camera
    params['picam2'].configure(capture_config)
    params['picam2'].start()
    logger.info('Starting camera')

    logger.info('Beginning image capture')
    if angles <= 1:
        major_steps = 1000
    else:
        major_steps = int(1000 / angles)
    if pansize > 0:
        pan_steps = int(pansize / 0.36 + 0.5)
    steps = 0
    while steps < 1000:
        # assume the camera is looking at the middle of the window
        sleep(1)
        logger.info('Angle: {:7.2f}°'.format(params['motor'].position_deg))
        take_image_stack(params)
        params['stepper_positions'].append(params['motor'].position)

        if pansize > 0:
            # pan anticlockwise
            params['motor'].on()
            params['motor'].rotate_ccw(pan_steps)
            params['motor'].off()
            sleep(0.5)
            steps -= pan_steps
            logger.debug('Angle: {:7.2f}°'.format(
                params['motor'].position_deg))
            take_image_stack(params)
            params['stepper_positions'].append(params['motor'].position)
            sleep(1)

            # pan clockwise
            params['motor'].on()
            params['motor'].rotate_cw(pan_steps * 2)
            params['motor'].off()
            sleep(1)
            steps += (pan_steps * 2)
            logger.debug('Angle: {:7.2f}°'.format(
                params['motor'].position_deg))
            take_image_stack(params)
            params['stepper_positions'].append(params['motor'].position)
            sleep(1)

        # then move to the next slide
        logger.debug('Rotating to next slide')
        if pansize > 0:
            params['motor'].on()
            params['motor'].rotate_cw(major_steps - pan_steps)
            params['motor'].off()
            steps += major_steps - pan_steps
        elif angles > 1:
            params['motor'].on()
            params['motor'].rotate_cw(major_steps)
            params['motor'].off()
            steps += major_steps
        else:
            steps += major_steps

    # shut down camera system
    set_vcm_position(0)
    led.off()
    logger.debug('Camera LED off')
    params['picam2'].close()
    params['picam2'] = None
    params['motor'].off()

    # create focus stacks
    if stack:
        logger.info('Beginning focus stacking')
        for angle in params['stepper_positions']:
            # no stack for single image
            files_to_stack = list((PATH_PI /
                                   params['image_dir']).glob('*_stepper{:03}*.png'.format(angle)))
            if len(files_to_stack) == 1:
                logger.info('Only one image found for position '
                            + '{:d}'.format(angle))
                cmd = ('cp '
                       + str(files_to_stack[0])
                       + ' '
                       + str(PATH_PI / params['image_dir']) + '/'
                       + (params['image_ID']
                          + '_stepper{:03}'.format(angle)
                          + '_stack.png'))
                p = Popen(shlex.split(cmd))
                logger.debug('Copied single image and renamed as stack')
                if params['USB']:
                    cmd = ('cp '
                           + str(PATH_PI / params['image_dir']) + '/'
                           + (params['image_ID']
                              + '_stepper{:03}'.format(angle)
                              + '_stack.png')
                           + ' '
                           + str(PATH_USB / params['image_dir']) + '/'
                           + (params['image_ID']
                              + '_stepper{:03}'.format(angle)
                              + '_stack.png'))
                    p = Popen(shlex.split(cmd))
                    logger.debug('Copied image to USB memory stick')
            else:
                focus_stack(params, angle, delete_images=delete_images)

    # upload images
    if uploadall:
        files_to_upload = list(
            Path(PATH_PI / params['image_dir']).glob('*.png'))
        logger.info('Uploading all images')
    else:
        files_to_upload = list(
            Path(PATH_PI / params['image_dir']).glob('*_stack.png'))
        logger.info('Uploading image stacks')
    if len(files_to_upload) == 0:
        logger.warning('No images to upload')
    else:
        logger.info('Images to upload: {:d}'.format(len(files_to_upload)))

        # authenticate
        r = requests.post(URL_FS + 'login',
                          data=json.dumps(AUTH_FS))
        if r.status_code != 200:
            logger.warning('Unable to get access token for file upload')
            exit(1)
        else:
            headers = {'X-Auth': r.text}
            logger.info('Received access token for upload')

        for file in files_to_upload:
            logger.debug('Begin upload of ' + file.name)
            with open(file, 'rb') as f:
                img = f.read()
            r = requests.post((URL_FS + 'resources/'
                               + str(params['image_dir']) + '/'
                               + file.name
                               + '?override=true'),
                              headers=headers,
                              data=img
                              )
            if r.status_code == 200:
                logger.info('Uploaded ' + file.name)
            else:
                logger.warning('Error ' + str(r.status_code)
                               + ' when uploading ' + file.name)

        logger.info('Upload complete')

    logger.info('Imaging cycle complete')


if __name__ == "__main__":
    import argparse

    # parse command-line arguments
    parser = argparse.ArgumentParser(description='Capture illuminated image.')
    parser.add_argument('--crop',
                        help=('set fractional crop square: '
                              + 'x_frac y_frac width_frac height_frac'),
                        nargs=4,
                        type=float,
                        default=(0.0, 0.0, 1.0, 1.0))
    parser.add_argument('--slices', '-s',
                        help='Number of focal slices for stacking',
                        type=int,
                        default=5)
    parser.add_argument('--arducam', '-a',
                        help='Use Arducam IMX477 autofocus tuning file',
                        action='store_true',
                        default=True)
    parser.add_argument('--tune',
                        help='JSON tuning filename',
                        type=str,
                        default='')
    parser.add_argument('--minfocus',
                        help='Lowest acceptable value for focus metric',
                        type=float,
                        default=20.0)
    parser.add_argument('--stack',
                        help=('Use wavelet reconstruction for '
                              + 'extended depth of focus'),
                        action='store_true',
                        default=False)
    parser.add_argument('--angles',
                        help=('number of different angles to photograph '
                              + 'on cartridge wheel '
                              + '(-1 for no rotation)'),
                        type=int,
                        default=-1)
    parser.add_argument('--pansize',
                        help=('Degrees left and right of centre to '
                              + 'capture additional images '
                              + '(-1 for no pan)'),
                        type=float,
                        default=9.0)
    parser.add_argument('--uploadall',
                        help='Include focus stack images in upload',
                        action='store_true',
                        default=False)
    args = parser.parse_args()

    ImageCapture(crop=args.crop, slices=args.slices, arducam=args.arducam,
                 tune=args.tune, minfocus=args.minfocus, stack=args.stack,
                 angles=args.angles, pansize=args.pansize,
                 uploadall=args.uploadall)
