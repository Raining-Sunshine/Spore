import board
import time
import neopixel
pixels = neopixel.NeoPixel(board.D18, 12)
for i in range (0,12):
	pixels[i]=(199,21,133)
	time.sleep(10)
pixels.fill((0, 0, 0))
